function display() {  
    document.getElementById('login').style.display='none';
    document.getElementById('class').style.display='block';
    let username = document.getElementById('input').value;
    if (username == null || username == '' || username == ' ' || username == undefined) {
        alert('Please enter a Name to Proceed!');
        document.getElementById('login').style.display='block';
    document.getElementById('class').style.display='none';
    }
    var time = new Date().getHours();
    console.log(time)
     if(time < 12) {
     document.getElementById('salutation').innerHTML = `<h2>Good Morning,${username}</h2>` ;
     }
     else if(time > 12 && time <= 16) {
        document.getElementById('salutation').innerHTML = `<h2>Good Afternoon,${username}</h2>`;
         }
     else if(time >= 16 && time <= 24) {
     document.getElementById('salutation').innerHTML = `<h2>Good Evening,${username}</h2>`;
     }
}
function section() {
    let classes = document.getElementById('classes').value;
    if (classes == 'I' || classes == 'II' || classes == 'III' || classes == 'IV' || classes == 'V' || classes == 'VI' || classes == 'VII' || classes == 'VIII' || classes == 'Nursery' || classes == 'Jr KG' || classes == 'Sr KG' || classes == 'IX' || classes == 'X' || classes == 'XI' || classes == 'XII') {
        document.getElementById('class').style.display='none';
        document.getElementById('section').style.display='block';
    }
    else {
        alert('Invalid Class Entered!'); 
        document.getElementById('class').style.display='block';
        document.getElementById('section').style.display='none';
    }
}
function home() {
    let section = document.getElementById('section-input').value;
    if (section == 'Adorable' || section == 'Bold' || section == 'Confident' || section == 'Diligent' || section == 'Elegant' || section == 'CAIE' ||section == 'ADORABLE' || section == 'BOLD' || section == 'CONFIDENT' || section == 'DILIGENT' || section == 'ELEGANT' || section == 'Caie' || section == 'caie') {
    document.getElementById('section').style.display='none';
    document.getElementById('home').style.display='block';
    }
    else {
        alert('Invalid Section Entered!');
        document.getElementById('section').style.display='block';
    document.getElementById('home').style.display='none';
    }
}
function classes() {
}
function homework() {
    window.location = `http://www.gobindgarhpublicschool.in/Examination/CBSEHomeWork/StudentsHomeWorkView.php?CLASS=${document.getElementById('classes').value}_${document.getElementById('section-input').value}&SecurityKey=8584`;
}
function syllabus() {
    let subject = document.getElementById('syllabus-input').value;
    if (subject == 'Social Studies') {
        window.location = `http://www.gobindgarhpublicschool.in/Syllabus_2020_21/SubjectSyllabusLogin1.php?CLASS=VIII&SUBJECT=Social_Science`;
    }
    else if (subject == 'General Knowledge') {
        window.location = `http://www.gobindgarhpublicschool.in/Syllabus_2020_21/SubjectSyllabusLogin1.php?CLASS=VIII&SUBJECT=Social_Science`;
    }
    else if (subject == 'English') {
        window.location = `http://www.gobindgarhpublicschool.in/Syllabus_2020_21/SubjectSyllabusLogin1.php?CLASS=${document.getElementById('classes').value}&SUBJECT=${subject}`;
    }
    else if (subject == 'Mathematics') {
        window.location = `http://www.gobindgarhpublicschool.in/Syllabus_2020_21/SubjectSyllabusLogin1.php?CLASS=${document.getElementById('classes').value}&SUBJECT=${subject}`;
    }
    else if (subject == 'Hindi') {
        window.location = `http://www.gobindgarhpublicschool.in/Syllabus_2020_21/SubjectSyllabusLogin1.php?CLASS=${document.getElementById('classes').value}&SUBJECT=${subject}`;
    }
    else if (subject == 'Punjabi') {
        window.location = `http://www.gobindgarhpublicschool.in/Syllabus_2020_21/SubjectSyllabusLogin1.php?CLASS=${document.getElementById('classes').value}&SUBJECT=${subject}`;
    }
    else if (subject == 'Science') {
        window.location = `http://www.gobindgarhpublicschool.in/Syllabus_2020_21/SubjectSyllabusLogin1.php?CLASS=${document.getElementById('classes').value}&SUBJECT=${subject}`;
    }
    else if (subject == 'Social Science') {
        window.location = `http://www.gobindgarhpublicschool.in/Syllabus_2020_21/SubjectSyllabusLogin1.php?CLASS=${document.getElementById('classes').value}&SUBJECT=${subject}`;
    }
    else {
        alert('Invalid Subject Entered!')
        document.getElementById('syllabus').style.display = 'block';
    }
}
function timetable() {
    window.location = `http://www.gobindgarhpublicschool.in/Syllabus_2020_21/ClassesTimeTableLogin.php`;
}
function subject() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('syllabus').style.display = 'block';
}